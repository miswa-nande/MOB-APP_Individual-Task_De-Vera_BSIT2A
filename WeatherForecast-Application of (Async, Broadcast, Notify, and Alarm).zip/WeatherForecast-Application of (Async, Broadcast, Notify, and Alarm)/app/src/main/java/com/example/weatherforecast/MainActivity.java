package com.example.weatherforecast;

import android.Manifest;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.ConnectivityManager;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.airbnb.lottie.LottieAnimationView;

public class MainActivity extends AppCompatActivity {

    private TextView temperatureText;
    private TextView conditionText;
    private LottieAnimationView animationView;
    private EditText cityInput;
    private Button refreshButton;

    private final String defaultCity = "Philippines";
    private final String PREFS_NAME = "weather_prefs";
    private final String PREF_CITY_KEY = "selected_city";

    private BroadcastReceiver weatherUpdateReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            // When network is connected, refresh the weather for the saved city
            SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
            String city = prefs.getString(PREF_CITY_KEY, defaultCity);
            fetchWeather(city);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.weatherAnimation), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        temperatureText = findViewById(R.id.temperatureText);
        conditionText = findViewById(R.id.conditionText);
        animationView = findViewById(R.id.weatherAnimation);
        cityInput = findViewById(R.id.cityInput);
        refreshButton = findViewById(R.id.refreshButton);

        WeatherUpdateScheduler.scheduleUpdates(this);

        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        String savedCity = prefs.getString(PREF_CITY_KEY, defaultCity);

        cityInput.setText(savedCity);
        fetchWeather(savedCity);

        refreshButton.setOnClickListener(v -> {
            String city = cityInput.getText().toString().trim();
            if (city.isEmpty()) {
                city = defaultCity;
            }
            prefs.edit().putString(PREF_CITY_KEY, city).apply();
            fetchWeather(city);
        });

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                    != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.POST_NOTIFICATIONS}, 1001);
            }
        }
    }

    public void refreshWeather(String city) {
        if (city == null || city.isEmpty()) {
            SharedPreferences prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
            city = prefs.getString(PREF_CITY_KEY, defaultCity);
        }
        fetchWeather(city);
    }

    private NetworkChangeReceiver networkChangeReceiver = new NetworkChangeReceiver();

    @Override
    protected void onResume() {
        super.onResume();

        // Register for connectivity change
        registerReceiver(networkChangeReceiver, new IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION));

        // Register for internal weather update broadcast
        IntentFilter updateFilter = new IntentFilter("com.example.weatherforecast.ACTION_UPDATE_WEATHER");
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            registerReceiver(weatherUpdateReceiver, updateFilter, Context.RECEIVER_NOT_EXPORTED);
        } else {
            registerReceiver(weatherUpdateReceiver, updateFilter);
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        unregisterReceiver(networkChangeReceiver);
        unregisterReceiver(weatherUpdateReceiver);
    }


    private void fetchWeather(String city) {
        new WeatherFetchTask(MainActivity.this, temperatureText, conditionText, animationView).execute(city);
    }
}
