package com.example.weatherforecast;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.util.Log;
import android.widget.Toast;

public class WeatherUpdateReceiver extends BroadcastReceiver {

    private static final String TAG = "WeatherUpdateReceiver";
    private static final String PREFS_NAME = "weather_prefs";
    private static final String PREF_CITY_KEY = "selected_city";
    private static final String DEFAULT_CITY = "Philippines";

    @Override
    public void onReceive(Context context, Intent intent) {
        Log.d(TAG, "Alarm triggered: attempting to fetch weather update");
        Toast.makeText(context, "Weather alarm triggered! Updating...", Toast.LENGTH_SHORT).show();

        try {
            SharedPreferences prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
            String city = prefs.getString(PREF_CITY_KEY, DEFAULT_CITY);

            if (city == null || city.trim().isEmpty()) {
                city = DEFAULT_CITY;
            }

            new WeatherFetchTask(context, null, null, null).execute(city);
        } catch (Exception e) {
            Log.e(TAG, "Failed to fetch weather update", e);
            Toast.makeText(context, "Error updating weather", Toast.LENGTH_SHORT).show();
        }
    }
}
