package com.example.weatherforecast;

import android.content.Context;
import android.os.AsyncTask;
import android.widget.TextView;

import com.airbnb.lottie.LottieAnimationView;
import com.google.gson.Gson;

import java.lang.ref.WeakReference;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

public class WeatherFetchTask extends AsyncTask<String, Void, WeatherData> {

    private final WeakReference<Context> contextRef;
    private final WeakReference<TextView> tempTextRef;
    private final WeakReference<TextView> conditionTextRef;
    private final WeakReference<LottieAnimationView> animationRef;

    // Store city name for use in onPostExecute
    private String city;

    public WeatherFetchTask(Context context,
                            TextView tempText,
                            TextView conditionText,
                            LottieAnimationView animationView) {
        this.contextRef = new WeakReference<>(context);
        this.tempTextRef = tempText != null ? new WeakReference<>(tempText) : null;
        this.conditionTextRef = conditionText != null ? new WeakReference<>(conditionText) : null;
        this.animationRef = animationView != null ? new WeakReference<>(animationView) : null;
    }

    @Override
    protected WeatherData doInBackground(String... params) {
        city = params[0];  // Save city here for later use
        OkHttpClient client = new OkHttpClient();

        Request request = new Request.Builder()
                .url("https://api.openweathermap.org/data/2.5/weather?q=" + city +
                        "&appid=47f453235bd87e7635708be2f93a81bf&units=metric")
                .build();

        try (Response response = client.newCall(request).execute()) {
            if (!response.isSuccessful() || response.body() == null) return null;
            String jsonData = response.body().string();
            return new Gson().fromJson(jsonData, WeatherData.class);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    @Override
    protected void onPostExecute(WeatherData weatherData) {
        if (weatherData == null) return;

        TextView tempText = tempTextRef != null ? tempTextRef.get() : null;
        TextView conditionText = conditionTextRef != null ? conditionTextRef.get() : null;
        LottieAnimationView animationView = animationRef != null ? animationRef.get() : null;

        if (tempText != null && conditionText != null && animationView != null) {
            tempText.setAlpha(0f);
            tempText.setText(weatherData.getTemperature() + "°C");
            tempText.animate().alpha(1f).setDuration(1000).start();

            conditionText.setTranslationY(50f);
            conditionText.setText(weatherData.getCondition());
            conditionText.animate().translationY(0f).setDuration(800).start();

            switch (weatherData.getCondition().toLowerCase()) {
                case "rain":
                    animationView.setAnimation(R.raw.rain_animation);
                    break;
                case "sunny":
                    animationView.setAnimation(R.raw.sun_animation);
                    break;
                default:
                    animationView.setAnimation(R.raw.clouds_animation);
                    break;
            }
            animationView.playAnimation();
        }

        Context context = contextRef.get();
        if (context != null) {
            WeatherNotification.showWeatherUpdate(context, weatherData, city);

            if (weatherData.isSevere()) {
                WeatherNotification.showWeatherAlert(context, weatherData);
            }
        }
    }
}
