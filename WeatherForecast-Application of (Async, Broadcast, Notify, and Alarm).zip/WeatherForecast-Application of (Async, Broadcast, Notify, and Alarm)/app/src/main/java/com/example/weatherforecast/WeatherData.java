package com.example.weatherforecast;

public class WeatherData {
    private Main main;
    private Weather[] weather;

    public float getTemperature() {
        return main.temp;
    }

    public String getCondition() {
        return weather.length > 0 ? weather[0].main : "Unknown";
    }

    public boolean isSevere() {
        // Define your own logic, e.g., high wind speed, storm, etc.
        String condition = getCondition().toLowerCase();
        return condition.contains("storm") || condition.contains("extreme");
    }

    private class Main {
        float temp;
    }

    private class Weather {
        String main;
    }
}
